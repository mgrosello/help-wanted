/*

Example script:

var sketch = context.api(context);

log(sketch.version());

var app = sketch.application();
log(app.version());
log(app.build());
log(app.full_version());


var document = sketch.context_document();
var selection = document.selection();
var pages = document.pages();
var page = pages[0];

var group = page.add_group("Test", CGRectMake(0, 0, 100, 100));
var rect = group.add_rectangle("Rect", CGRectMake(10, 10, 80, 80));

log(selection.is_empty());
selection.iterate(function(item) { log(item.name); } );

selection.clear();
log(selection.is_empty());

group.select();
rect.add_to_selection();

app.input("Test", "default");
app.select("Test", ["One", "Two"], 1);
app.message("Hello mum!");
app.alert("Title", "message");



*/


"use strict";




(function(context) {

  function SketchBase() {
  }


  SketchBase.prototype.test = function() {
    return "base";
  }


  // ********************************
  // Application support.
  // ********************************

  function Application() {
    SketchBase.call(this);
    this.context = context
    this.metadata = [MSApplicationMetadata metadata];
  }

  Application.prototype = Object.create(SketchBase.prototype);
  Application.prototype.constructor = Application;

  Application.prototype.version = function() {
    return this.metadata['appVersion'];
  }

  Application.prototype.build = function() {
    return this.metadata['build'];
  }

  Application.prototype.full_version = function() {
    return this.version() + " (" + this.build() + ")";
  }

  Application.prototype.get_setting = function(key) {
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
  }

  Application.prototype.set_setting = function(key, value) {
    [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
  }

  Application.prototype.input = function(msg, initial) {
    return this.context.document.askForUserInput_initialValue(msg, initial);
  }

  Application.prototype.select = function(msg, items, selectedItemIndex) {
    selectedItemIndex = selectedItemIndex || 0

    var accessory = NSComboBox.alloc().initWithFrame(NSMakeRect(0,0,200,25))
    accessory.addItemsWithObjectValues(items)
    accessory.selectItemAtIndex(selectedItemIndex)

    var alert = NSAlert.alloc().init()
    alert.setMessageText(msg)
    alert.addButtonWithTitle('OK')
    alert.addButtonWithTitle('Cancel')
    alert.setAccessoryView(accessory)

    var responseCode = alert.runModal()
    var sel = accessory.indexOfSelectedItem()

    return [responseCode, sel]
  }

  Application.prototype.message = function(msg) {
    this.context.document.showMessage(msg);
  }

  Application.prototype.alert = function(title, msg) {
    var app = NSApplication.sharedApplication()
    app.displayDialog_withTitle(title, msg);
  }

  // ********************************
  // Layer support.
  // TODO: split this functionality up properly into wrappers for the main layer classes
  // ********************************

  function Layer(layer) {
    SketchBase.call(this);
    this.sketchObject = layer;
  }

  Layer.prototype = Object.create(SketchBase.prototype);
  Layer.prototype.constructor = Layer;

  Layer.prototype.object = function() {
    return this.sketchObject;
  }

  Layer.prototype.name = function() {
    return this.sketchObject.name();
  }

  Layer.prototype.id = function() {
    return this.sketchObject.objectID();
  }

  Layer.prototype.is_page = function() {
    var layer = this.sketchObject;
    return [layer class] == MSPage;
  }

  Layer.prototype.is_artboard = function() {
    var layer = this.sketchObject;
    return [layer class] == MSArtboardGroup;
  }

  Layer.prototype.is_group = function() {
    var layer = this.sketchObject;
    return [layer class] == MSLayerGroup;
  }

  Layer.prototype.is_text = function() {
    var layer = this.sketchObject;
    return [layer class] == MSTextLayer;
  }

  Layer.prototype.is_shape = function() {
    var layer = this.sketchObject;
    return [layer class] == MSShapeGroup;
  }

  Layer.prototype.add_layer_with_name = function(newLayer, name) {
    if (newLayer) {
      newLayer.setName_(name);
      var layer = this.sketchObject;
      [layer addLayers:[NSArray arrayWithObject:newLayer]];
      return new Layer(newLayer);
    }
  }

  Layer.prototype.add_rectangle = function(name, frame) {
    var newLayer = [MSShapeGroup shapeWithBezierPath:[NSBezierPath bezierPathWithRect:frame]];
    return this.add_layer_with_name(newLayer, name);
  }

  Layer.prototype.add_text = function(name, frame, text) {
    var newLayer = [[MSTextLayer alloc] initWithFrame:frame];
    [newLayer adjustFrameToFit];
    return this.add_layer_with_name(newLayer, name);
  }

  Layer.prototype.add_group = function(name, frame) {
    var newLayer = [[MSLayerGroup alloc] initWithFrame:frame];
    return this.add_layer_with_name(newLayer, name);
  }

  Layer.prototype.add_artboard = function(name, frame) {
    var newLayer = [[MSArtboardGroup alloc] initWithFrame:frame];
    return this.add_layer_with_name(newLayer, name);
  }

  Layer.prototype.add_image = function(name, frame) {
    var newLayer = [[MSLayerGroup alloc] initWithFrame:frame];
    return this.add_layer_with_name(newLayer, name);
  }

  Layer.prototype.remove = function() {
    var parent = [layer parentGroup];
    if (parent)
    [parent removeLayer:layer];
  }

  Layer.prototype.select = function() {
    this.sketchObject.select_byExpandingSelection(true, false);
  }

  Layer.prototype.deselect = function() {
    this.sketchObject.select_byExpandingSelection(false, true);
  }

  Layer.prototype.add_to_selection = function() {
    this.sketchObject.select_byExpandingSelection(true, true);
  }

  Layer.prototype.iterate = function(block) {
    print("blah");
    var loop = this.sketchObject().layers().objectEnumerator();
    while (item = loop.nextObject()) {
      block(new Layer(item));
    }
  }


  // ********************************
  // Selection support.
  // ********************************

  function Selection(document) {
    SketchBase.call(this);
    this.sketchObject = document;
  }

  Selection.prototype = Object.create(SketchBase.prototype);
  Selection.prototype.constructor = Selection;

  Selection.prototype.is_empty = function() {
    return (this.sketchObject.selectedLayers().count() == 0);
  }

  Selection.prototype.iterate = function(block) {
    var loop = this.sketchObject.selectedLayers().objectEnumerator();
    var item;
    while (item = loop.nextObject()) {
      block(new Layer(item));
    }
  }

  Selection.prototype.clear = function() {
    this.sketchObject.currentPage().deselectAllLayers();
  }


  // ********************************
  // Document support.
  // ********************************

  function Document(document) {
    SketchBase.call(this);
    this.sketchObject = document;

  }

  Document.prototype = Object.create(SketchBase.prototype);
  Document.prototype.constructor = Document;

  Document.prototype.object = function() {
    return this.sketchObject;
  }

  Document.prototype.selection = function() {
    return new Selection(this.sketchObject)
  }

  Document.prototype.pages = function() {
    var result = [];
    var loop = this.sketchObject.pages().objectEnumerator();
    var item;
    while (item = loop.nextObject()) {
      result.push(new Layer(item));
    }
    return result;
  }

  Document.prototype.layer_with_id = function(layer_id) {
    return new Layer(this.sketchObject.documentData().layerWithID_(layer_id));
  }

  Document.prototype.layer_with_name = function(layer_id) {
    // as it happens, layerWithID also matches names
    return new Layer(this.sketchObject.documentData().layerWithID_(layer_id));
  }


  return {
    "version" : function() {
      return "1.0.0";
    },

    "application" : function() {
      return new Application(context);
    },

    "context_document" : function() {
      return new Document(context.document);
    },

    "document" : function(document) {
      return new Document(document);
    }
  }

});
